#!/usr/bin/bash

systemctl daemon-reload
systemctl restart fx-autotrade.service