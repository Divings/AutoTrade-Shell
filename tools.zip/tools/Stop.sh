#!/usr/bin/bash
systemctl stop fx-autotrade.service
